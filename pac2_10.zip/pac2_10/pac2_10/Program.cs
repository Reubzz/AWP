﻿using System;

namespace ExceptionHandlingExample
{
    class NotEvenException : Exception
    {
        public NotEvenException(string msg)
            : base(msg)
        {
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int num;

            try
            {
                Console.Write("Enter a number: ");
                num = int.Parse(Console.ReadLine());

                if ((num % 2) != 0)
                    throw new NotEvenException("Not an even number");
                else
                    Console.WriteLine("It's an even number");
            }
            catch (NotEvenException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
