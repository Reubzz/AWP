﻿using System;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int row, col;
            for (row = 1; row <= 5; row++)
            {
                for (col = 1; col <= row; col++)
                    Console.Write(col);
                Console.WriteLine();
            }
        }
    }
}