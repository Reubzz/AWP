﻿using System;
namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int var1, var2;
            Console.Write("Enter number 1: ");
            var1 = Int32.Parse(Console.ReadLine());
            Console.Write("Enter number 2: ");
            var2 = Convert.ToInt32(Console.ReadLine());
            if ((var1 > 10 && var2 <= 10) || (var2 > 10 && var1 <= 10))
            {
                Console.WriteLine("Boolean test succedded \n Both number are not >10");
            }
        }
    }
}