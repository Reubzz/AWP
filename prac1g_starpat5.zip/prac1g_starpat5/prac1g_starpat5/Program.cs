﻿using System;
namespace pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            int row, col, sp, reverse;
            for (row = 1; row <= 5; row++)
            {
                for (sp = 1; sp <= 5 - row; sp++)
                    Console.Write(" ");
                for (col = 1; col <= row; col++)
                    if (col == 1)
                        Console.Write("*");
                    else
                        Console.Write(" ");
                for (reverse = col - 2; reverse >= 1; reverse--)
                    if (reverse == 1)
                        Console.Write("*");
                    else
                        Console.Write(" ");
                Console.WriteLine();
            }
            for (row = 4; row >= 1; row--)
            {
                for (sp = 1; sp <= 5 - row; sp++)
                    Console.Write(" ");
                for (col = 1; col <= row; col++)
                    if (col == 1)
                        Console.Write("*");
                    else
                        Console.Write(" ");
                for (reverse = col - 2; reverse >= 1; reverse--)
                    if (reverse == 1)
                        Console.Write("*");
                    else
                        Console.Write(" ");
                Console.WriteLine();
            }
        }
    }
}