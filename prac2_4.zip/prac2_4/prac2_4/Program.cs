﻿using System;

namespace SingleInheritance
{
    class Furniture
    {
        string material;
        float price;

        public void GetData()
        {
            Console.Write("Enter material: ");
            material = Console.ReadLine();
            Console.Write("Enter price: ");
            price = float.Parse(Console.ReadLine());
        }

        public void ShowData()
        {
            Console.WriteLine("Material: " + material);
            Console.WriteLine("Price: " + price);
        }
    }

    class Table : Furniture
    {
        int height, surfaceArea;

        public new void GetData()
        {
            base.GetData();
            Console.Write("Enter height: ");
            height = int.Parse(Console.ReadLine());
            Console.Write("Enter surface area: ");
            surfaceArea = int.Parse(Console.ReadLine());
        }

        public new void ShowData()
        {
            base.ShowData();
            Console.WriteLine("Height: " + height);
            Console.WriteLine("Surface Area: " + surfaceArea);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Table t1 = new Table();
            t1.GetData();
            t1.ShowData();
        }
    }
}
