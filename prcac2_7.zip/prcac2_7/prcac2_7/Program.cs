﻿using System;

namespace HeirarchicalInheritance
{
    class Employee
    {
        public virtual void Display()
        {
            Console.WriteLine("Display of Employee class called");
        }
    }

    class Programmer : Employee
    {
        public new void Display()
        {
            Console.WriteLine("Display of Programmer class called");
        }
    }

    class Manager : Employee
    {
        public new void Display()
        {
            Console.WriteLine("Display of Manager class called");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Programmer objProgrammer;
            Manager objManager;

            Console.Write("Whose details do you want to see?\n1. Programmer\n2. Manager\n");

            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                objProgrammer = new Programmer();
                objProgrammer.Display();
            }
            else if (choice == 2)
            {
                objManager = new Manager();
                objManager.Display();
            }
            else
            {
                Console.WriteLine("Wrong choice entered");
            }
        }
    }
}
