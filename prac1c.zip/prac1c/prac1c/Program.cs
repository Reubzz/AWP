﻿using System;
namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int var1, var2;
        label1:
            Console.Write("Enter number 1: ");
            var1 = Int32.Parse(Console.ReadLine());
            Console.Write("Enter number 2: ");
            var2 = Convert.ToInt32(Console.ReadLine());
            if ((var1 > 10 && var2 > 10))
            {
                Console.WriteLine("Both No are greater than 10 are not allowed");
                goto label1;
            }
            else
            {
                Console.WriteLine("Number 1: " + var1);
                Console.WriteLine("Number 2 :" + var2);
            }
        }
    }
}