﻿using System;

namespace SalaryConstructure
{
    class Salary
    {
        int basic, ta, da, hra;

        public Salary()
        {
            da = 9000;
            hra = 6000;
        }

        public void GetData()
        {
            Console.Write("Enter basic salary: ");
            basic = int.Parse(Console.ReadLine());
            Console.Write("Enter travelling allowance: ");
            ta = int.Parse(Console.ReadLine());
        }

        public void ShowData()
        {
            Console.WriteLine("Basic salary: " + basic);
            Console.WriteLine("Dearness allowance: " + da);
            Console.WriteLine("Housing rent allowance: " + hra);
            Console.WriteLine("Travelling allowance: " + ta);
            Console.WriteLine("Gross Salary: " + (basic + da + hra + ta));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Salary s = new Salary();
            s.GetData();
            s.ShowData();
        }
    }
}
