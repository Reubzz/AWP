﻿using System;

namespace multilevelinheritance
{
    class Student
    {
        int roll_no;
        string name;

        public Student(int roll_no, string name)
        {
            this.roll_no = roll_no;
            this.name = name;
        }

        public Student() { }

        public void Display()
        {
            Console.WriteLine("Roll no: " + roll_no);
            Console.WriteLine("Name: " + name);
        }
    }

    class Test : Student
    {
        int marks1, marks2;

        public Test(int roll_no, string name, int marks1, int marks2)
            : base(roll_no, name)
        {
            this.marks1 = marks1;
            this.marks2 = marks2;
        }

        public int GetMarks1()
        {
            return marks1;
        }

        public int GetMarks2()
        {
            return marks2;
        }

        public void Display()
        {
            base.Display();
            Console.WriteLine("Marks1: " + marks1);
            Console.WriteLine("Marks2: " + marks2);
        }
    }

    class Result : Test
    {
        int total;

        public Result(int roll_no, string name, int marks1, int marks2)
            : base(roll_no, name, marks1, marks2)
        {
            total = GetMarks1() + GetMarks2();
        }

        public new void Display()
        {
            base.Display();
            Console.WriteLine("Total: " + total);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Result r1 = new Result(101, "Prachit", 50, 70);
            r1.Display();
        }
    }
}
