﻿using System;
namespace distanceclass
{
    class Distance
    {
        int dist1, dist2, dist3;
        public Distance(int dist1, int dist2)
        {
            this.dist1 = dist1;
            this.dist2 = dist2;
        }
        public void addition()
        {
            dist3 = dist1 + dist2;
        }
        public void display()
        {
            Console.WriteLine("Distance1:" + dist1);
            Console.WriteLine("Distance1:" + dist2);
            Console.WriteLine("Distance1:" + dist3);
        }
    }
    class program
    {
        static void Main(string[] args)
        {
            Distance objDistance = new Distance(10, 20);
            objDistance.addition();
            objDistance.display();
        }
    }
}